#!/bin/bash

ES=/home/vagrant/node1
kill `cat < $ES/bin/es1.pid`